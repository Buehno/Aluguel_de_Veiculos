from funcoes_loja import *

alugar()